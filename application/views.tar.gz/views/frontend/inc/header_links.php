<!-- ========== Favicon Icon ========== -->
<link rel="shortcut icon" href="<?=base_url()?>assets/frontend/img/favicon.png" type="image/x-icon">


<?php if (!empty($this->session->userdata('logged_in_user_data')) && $this->uri->segment(1) == 'user') { ?>
<link href="<?=base_url()?>assets/frontend/css/style2.css" rel="stylesheet">
<link href="<?=base_url()?>assets/frontend/css/inilab.css" rel="stylesheet">
<?php } ?>




<!-- ========== Start Stylesheet ========== -->
<link href="<?=base_url()?>assets/frontend/css/bootstrap.min.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/font-awesome.min.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/flaticon-set.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/magnific-popup.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/owl.carousel.min.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/owl.theme.default.min.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/animate.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/bootsnav.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/style.css" rel="stylesheet">
<link href="<?=base_url()?>assets/frontend/css/responsive.css" rel="stylesheet" />
<link href="<?=base_url()?>assets/frontend/css/common.css" rel="stylesheet">

<?php if ($this->uri->segment('3') === 'start') {?>
  <link type="text/css" href="<?=base_url('assets/frontend/css/fuelux.css')?>" rel="stylesheet">
  <link href="<?=base_url()?>assets/frontend/css/combined.css" rel="stylesheet">
  <link href="<?=base_url()?>assets/frontend/css/checkbox.css" rel="stylesheet">
<?php } ?>

<!-- ========== End Stylesheet ========== --> 

<!-- ========== Google Fonts ========== -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">
<style>
.overflow-ellipsis { text-overflow: ellipsis}
</style>